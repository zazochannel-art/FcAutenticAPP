# FC Autentic - versiune verificată

Proiect Expo / React Native pregătit pentru rulare în Expo Go.

## Pornire

```bash
npm install
npm run tunnel
```

Scanează codul QR cu aplicația Expo Go.

## Supabase

1. Copiază `.env.example` în `.env`.
2. Completează:

```env
EXPO_PUBLIC_SUPABASE_URL=https://proiectul-tau.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=cheia-ta-anon
```

Fără `.env`, aplicația pornește în mod demo/local.

## Verificat

- `babel-preset-expo` adăugat în devDependencies.
- `@opentelemetry/api` adăugat pentru compatibilitatea Supabase cu Metro.
- iconițele au fost mutate și în `assets/`, conform `app.json` și `App.js`.
- pluginul inutil `expo-asset` din `app.json` a fost eliminat pentru a evita eroarea de rezolvare plugin.
- test build web: OK.
- test bundle Android/Expo Go: OK.
